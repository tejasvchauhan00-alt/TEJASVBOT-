# TEJASVBOT 2.0

Personal AI assistant PWA powered by Google Gemini.

## Publish with GitHub Pages
1. Upload these files to the repository root (not inside a subfolder).
2. Open Settings → Pages.
3. Choose Deploy from a branch, branch `main`, folder `/(root)`, then Save.
4. When GitHub shows the published URL, open it in Chrome on Android and choose Install app / Add to Home screen.

## Gemini key
Open Settings inside the app and enter your own Gemini API key. The key is saved in this browser only; it is not included in these files. This client-side prototype is intended for personal testing. Browser apps cannot keep API keys secret from people who can inspect the app or device. For a public multi-user app, use a backend with the key stored server-side.
